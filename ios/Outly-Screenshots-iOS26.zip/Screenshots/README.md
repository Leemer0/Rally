# Outly iOS screen gallery

Captured from the Outly debug build on an iPhone 17 Pro simulator running iOS 26.5. Each original screenshot is 368 × 800 pixels.

## Contact sheets

- [Onboarding](ContactSheets/onboarding.jpg)
- [Discovery and planning](ContactSheets/discovery-planning.jpg)
- [Check-in and offers](ContactSheets/check-in.jpg)
- [Sheets](ContactSheets/sheets.jpg)

## Onboarding

1. [Welcome](Onboarding/01-welcome.jpg)
2. [Authentication](Onboarding/02-authentication.jpg)
3. [Name](Onboarding/03-name.jpg)
4. [Age](Onboarding/04-age.jpg)
5. [Onboarding complete](Onboarding/05-complete.jpg)

## Discovery

6. [Explore](Discovery/06-explore.jpg)
7. [Venues](Discovery/07-venues.jpg)
8. [Profile](Discovery/08-profile.jpg)

## Venue and planning

9. [Venue detail](Planning/09-venue-detail.jpg)
10. [Arrival time](Planning/10-arrival-time.jpg)
11. [Group size](Planning/11-group-size.jpg)
12. [Review plan](Planning/12-review-plan.jpg)
13. [Plan confirmed](Planning/13-plan-confirmed.jpg)

## Check-in and offers

14. [Check-in introduction](CheckIn/14-check-in-intro.jpg)
15. [Scan code](CheckIn/15-scan-code.jpg)
16. [Verify location](CheckIn/16-verify-location.jpg)
17. [Check-in success](CheckIn/17-check-in-success.jpg)
18. [Offer](CheckIn/18-offer.jpg)
19. [Redemption confirmation](CheckIn/19-redeem-confirmation.jpg)
20. [Offer redeemed](CheckIn/20-offer-redeemed.jpg)

## Sheets

21. [Venue search](Sheets/21-search.jpg)
22. [Filters](Sheets/22-filters.jpg)
23. [Settings](Sheets/23-settings.jpg)
24. [Privacy](Sheets/24-privacy.jpg)
25. [Help and support](Sheets/25-support.jpg)
26. [About this prototype](Sheets/26-about.jpg)
